/**
 * 小程序配置文件
 */

export default {
    // 云开发环境 ID
    envId: 'luowang01-05e98', // release
    // envId: 'test-f0b102',
}
