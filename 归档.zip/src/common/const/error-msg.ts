export const BlueToothErrorMsg = {
    not_available: 10001,
    not_init: 10000, // 未初始化蓝牙适配器
};
